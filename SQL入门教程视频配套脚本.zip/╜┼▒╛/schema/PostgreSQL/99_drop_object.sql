DROP TABLE departments CASCADE;
DROP TABLE jobs        CASCADE;
DROP TABLE employees   CASCADE;

