DROP TABLE departments;
DROP TABLE jobs;
DROP TABLE employees;


