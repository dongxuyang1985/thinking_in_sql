PRAGMA foreign_keys=off;

DROP TABLE departments;
DROP TABLE jobs;
DROP TABLE employees;

PRAGMA foreign_keys=on;
