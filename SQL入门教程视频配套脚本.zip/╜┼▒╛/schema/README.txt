六个目录分别是六种数据库使用的脚本：Db2、MySQL、Oracle、PostgreSQL、SQL Server 以及 SQLite 。

每个数据库目录都包含以下文件：
创建表：  01_create_table.sql
插入数据：02_generate_data.sql
创建索引：03_create_index.sql
清除表：  99_drop_object.sql